import hashlib

pass_found = 0
i_hash = input("Enter the hash: ")
p_doc = input("Enter the password file name: ")

with open(p_doc, "r") as file:
    for line in file.readlines():
        enc_word = line.strip().encode("utf-8")
        hash_word = hashlib.md5(enc_word).hexdigest()
        if hash_word == i_hash:
            print(f"Password found: {line.strip()}")
            pass_found = 1
            break

if pass_found == 0:
    print("Password is not in the dictionary")
