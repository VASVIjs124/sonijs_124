import nmap
import socket

# The nmap module is used for network exploration and security auditing.
# The socket module is used for low-level networking interface.

def scan(target):
    # Create an instance of the PortScanner class from the nmap module.
    nm = nmap.PortScanner()

    # Scan the target host using a SYN scan (-sS).
    nm.scan(target, arguments='sS')

    # Iterate through all the hosts found during the scan.
    for host in nm.all_hosts():
        # Get the hostname of the current host.
        mac = nm[host].hostname()

        # Iterate through all the protocols found for the current host.
        for proto in nm[host].all_protocols():
            # Get the list of open ports for the current protocol.
            lport = nm[host][proto].keys()

            # Iterate through all the open ports for the current protocol.
            for port in lport:
                # Get the state of the current port.
                state = nm[host][proto][port]['state']

                # Get the name of the service running on the current port.
                service = nm[host][proto][port]['name']

                # Get the product running on the current port.
                product = nm[host][proto][port]['product']

                # Get the version of the product running on the current port.
                version = nm[host][proto][port]['version']

                # Get any extra information about the current port.
                extrainfo = nm[host][proto][port]['extrainfo']

                # Return a string containing the scan results for the current port.
                return 'Target : %s\nhostname : %s\nProtocol : %s\nport : %s\tstate : %s\tservice : %s\tproduct : %s\tversion : %s\textrainfo : %s' % (host, mac, proto, port, state, service, product, version, extrainfo)

if __name__ == '__main__':
    # Get the IP address of the target host.
    target = socket.gethostbyname('www.google.com')

    # Print the scan results for the target host.
    print(scan(target))
