import scapy.all as scapy  # Importing the scapy library for packet manipulation
import re  # Importing the re library for regular expression operations
import socket  # Importing the socket library for low-level networking operations

def wifi(ip_add_range_entered):
    """
    This function uses the scapy library to perform an ARP scan on the given IP address range.
    It then extracts the IP address, MAC address, and hostname of each device found in the range.

    :param ip_add_range_entered: The IP address range to scan, as a string in the format 'x.x.x.x/xx'
    :return: A string containing the IP address, MAC address, and hostname of the first device found in the range
    """

    arp_result = scapy.arping(ip_add_range_entered, verbose=False)[0]  # Performing an ARP scan on the given range

    for sent, received in arp_result:
        ip = received.psrc  # Extracting the IP address of the device
        mac = received.hwsrc  # Extracting the MAC address of the device
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)  # Attempting to extract the hostname of the device
        except socket.herror:
            hostname = "Unknown"  # Setting the hostname to 'Unknown' if it cannot be extracted

        return f"IP: {ip} MAC: {mac} Hostname: {hostname}"  # Returning the IP address, MAC address, and hostname as a string