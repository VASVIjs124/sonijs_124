# Import necessary libraries
import geocoder
import folium
import socket

# Define a function to get the location from an IP address and create a map
def get_loc(url, path, file):
    # Get the IP address from the URL
    ip = socket.gethostbyname(url)
    
    # Use the IP address to get the latitude and longitude
    g = geocoder.ip(ip)
    myaddress = g.latlng

    # Create a map centered at the latitude and longitude
    myMap = folium.Map(location=myaddress, zoom_start=12)

    # Add a marker at the latitude and longitude
    folium.Marker(myaddress, popup="My Location").add_to(myMap)

    # Add a circle marker at the latitude and longitude
    folium.CircleMarker(myaddress, radius=50, color='red', fill_color='red').add_to(myMap)

    # Save the map to an HTML file
    myMap.save(path+file+".html")

    # Return the latitude and longitude as a string
    return f'Latitude: {myaddress[0]} Longitude: {myaddress[1]}\nLocation saved to {path+file}.html'

# Call the function if the script is run directly
if __name__ == "__main__":
    # Get the URL from the user
    url = input("Enter a url: ")

    # Call the get_loc function with the URL and a file name
    print(get_loc(url, "", 'test'))