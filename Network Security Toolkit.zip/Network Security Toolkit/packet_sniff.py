from scapy.all import *  # Importing the scapy library for packet manipulation
import socket  # Importing the socket library for creating socket objects

def packet(count):
    """
    This function captures the specified number of packets using the sniff function from scapy.

    :param count: The number of packets to capture
    :type count: int
    :return: A string containing the captured packets
    :rtype: str
    """
    pack = ""  # Initializing an empty string to store the captured packets
    packets = sniff(count = count)  # Using the sniff function to capture packets
    for packet in packets:
        pack += str(packet) + "\n"  # Converting each packet to a string and adding it to the pack string
    return pack

if __name__ == "__main__":
    print(packet(5))  # Calling the packet function with an argument of 5 and printing the result